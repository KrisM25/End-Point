//Importación de los paquetes
const express = require("express"); //para el manejo de las rutas
const http = require("http"); //procesamiento de peticiones http (web)
const mysql = require("mysql"); //módulo para gestionar la base de datos (consultas, etc)
const cors = require("cors");


const {listarTodasLasMarcas, consultaMarcaId,agregarMarca, eliminarMarca} = require("../Modulos/Marca/Marca.js");
const { listarTodosLosProductos } = require("../Modulos/Productos/Productos.js");


//Creación de una instancia de express
const app = express();

//vamos a indicarle al API que estará escuchando en el puerto 3000
const PORT = process.env.PORT || 3000;

//middleware para tener el acceso a las respuestas y peticiones del consumo
app.use(express.json());
app.use(cors())
app.use(express.urlencoded({extended:true}));


//empezamos a crear las rutas
app.get("/estado_api",(req, res) => {
    res.json(
        {
            estado: true,
            mensaje: "El servidor está online"
        }
    )
});

app.post("/agregarMarca",(req, res) => {
    agregarMarca(req, res);
});


/**
 * @api {POST} Listar todas las marcas por id y nombre
 * @apiName listarTodasLasMarcas
 * @apiGroup Marcas
 * @apiDescription Lista todas las marcas en orden por su id y nombre
 * @apiSuccess {Boolean} estado indica el estado de la operacion
 * @apiSuccess {Object} data JSON con todas las maras
 * 
 * @apiError {Boolean} Estado de la peticion
 * @apiError {String} Descripcion del error
 * 
 * @apiExample
 * {
 *      ID: 1 , Nombre: NYX
 * }
 */
app.post("/listarTodasLasMarcas", (req, res) => {
    listarTodasLasMarcas(req, res);
});



/**
 * @api {POST} Listar todas los productos
 * @apiName listarTodosLosProductos
 * @apiGroup Productos
 * @apiDescription Lista todos los productos por su id, nombre, marca, stock, proveedor y precio de cada producto.
 * @apiSuccess {Boolean} estado indica el estado de la operacion
 * @apiSuccess {Object} data JSON con todas las maras
 * 
 * @apiError {Boolean} Estado de la peticion
 * @apiError {String} Descripcion del error
 * 
 * @apiExample
 * {
 *      ID: 1 , Nombre: NYX
 * }
 */
app.post("/listarTodosLosProductos", (req, res) => {
    listarTodosLosProductos(req, res);
});


app.post("/consultaMarcaId", (req, res) =>{
    consultaMarcaId(req, res);
})

app.post("/eliminarMarca", (req, res) => {
    eliminarMarca(req, res);
});

//creamos el servidor
const server = http.createServer(app);
//le indicamos que estará escuchando en el puerto que definimos anteriormente
server.listen(PORT, () => { //Callback que se ejecuta cuando el puerto está listo

    console.log(`Servidor está escuchando en el puerto ${PORT}`);
});